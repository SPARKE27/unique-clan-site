import Head from 'next/head';
import HomePage from '../components/HomePage';

export default function Home() {
  return (
    <>
      <Head>
        <title>UNIQUE - Poxel.io Clan</title>
        <meta
          name="description"
          content="UNIQUE – The ultimate Poxel.io clan. A future e-sports team founded by NeoKing. Join our competitive divisions, scrims, tournaments, and rise to the top. Always UNIQUE, UNIQUE on TOP. Join our Discord today!"
        />
      </Head>
      <HomePage />
    </>
  );
}
